<?php 
class Database {
     private static $dbName = 'demopgco_lvb_new' ;
     private static $dbHost = 'localhost' ; 
     private static $dbUsername = 'demopgco_lvb_new';
     private static $dbUserPassword = 'demopgco_lvb_new';
     private static $cont = null;
     public function __construct() 
    { 
        die("La fonction init n'est pas autorisée");
    }
    public static function connect() 
    {
        if ( null == self::$cont ) 
        { 
            try 
            {
             self::$cont = new PDO( 
                 "mysql:host=".self::$dbHost.";".
                 "dbname=".self::$dbName, self::$dbUsername, self::$dbUserPassword
                );
            }
            catch(PDOException $e) 
            {

                die($e->getMessage()); 
            }
       }
       return self::$cont;
    }
     
    public static function disconnect()
    {
        self::$cont = null;
    }
}
/*
https://www.copier-coller.com/un-crud-en-php/
https://www.google.com/search?q=php+insert+in+database+radio+button+information&oq=php+insert+in+database+radio+button+info&aqs=chrome.1.69i57j33i160l2j33i21.29820j0j7&sourceid=chrome&ie=UTF-8
https://www.c-sharpcorner.com/UploadFile/051e29/insert-value-from-radio-button-in-mysql-in-php/
https://technosmarter.com/qa/514/how-to-insert-html-radio-button-value-in-database-using-php-with-mysql

*/
?>
