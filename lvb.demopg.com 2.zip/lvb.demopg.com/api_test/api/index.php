<?php
require_once("./api.php");
//lvb_demopg.com/articles
//lvb_demopg.com/articles/:categorie
//lvb_demopg.com/articles/:id
try{
if(!empty($_GET['demande'])){
    $url = explode("/",filter_var($_GET['demande'],FILTER_SANITIZE_URL));
    switch($url[0]){
            case "articles" :
                if(empty($url[1])){
                    getArticles();
                    /*var_dump(getArticles());
                    die();*/
                }else{
                    getArticlesParCategorie($url[1]);
                    /*var_dump(getArticlesParCategorie($url[1]));
                    die();*/
                }
            break;
            case "article" : 
                if(!empty($url[1])){
                    getArticleParId($url[1]);
                     /*var_dump(getArticleParId($url[1]));
                    die();*/
                    
                }else{
                   throw new Exception("Vous n'avez pas renseigné le numéro de l'article") ; 
                }
            break;
            default:throw new Exception("La demande n'est pas valide, vérifiez l'url") ;
    }
}else{
    throw new Exception("Problème de récupération de données .") ;
}
}catch(Exception $e){
    $erreur = [
        "message" => $e->getMessage(),
        "code"    => $e->getCode()
        ];
        print_r($erreur);
}


?>