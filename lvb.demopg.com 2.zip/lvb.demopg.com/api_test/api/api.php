<?php 
//Connexion à la BD
 require '../../database.php';
 // Pour afficher tous les articles
function getArticles(){
    $pdo = Database::connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $req = "SELECT articles.id, articles.libelle, articles.description, articles.image, articles.prix, articles.quantite, categorie.libelle 
    as 'categorie' FROM articles  inner join categorie on articles.idCategorie = categorie.id";
    $stmt = $pdo->prepare($req);
    $stmt->execute();
    $articles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    //print_r($articles);
    $stmt->closeCursor();
    echo json_encode($articles);
   
    
}
 // Pour afficher les articles par catégorie
function getArticlesParCategorie($categorie){
    $pdo = Database::connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $req = "SELECT articles.id, articles.libelle, articles.description, articles.image, articles.prix, articles.quantite, categorie.libelle 
        as 'categorie' FROM articles  INNER JOIN categorie  ON articles.idCategorie = categorie.id
    WHERE categorie.libelle = :categorie";
    $stmt = $pdo->prepare($req);
    $stmt->bindValue(":categorie",$categorie,PDO::PARAM_STR);
    $stmt->execute();
    $articles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    //print_r($articles);
    
    /* $tab = [
        0 => ['nom' => "DIDOU",
        'prenoms' => 'Mickael',
        'profession' => 'Informaticien'],
        1 => [
            'nom' => "DIDOU",
        'prenoms' => 'Mickael',
        'profession' => 'Informaticien'
        ]
    ]; */
    
    $stmt->closeCursor();
    echo json_encode($articles);
}
 // Pour afficher les articles par id c'est à dire un article bien précis
function getArticleParId($id){
    $pdo = Database::connect();
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $req = "SELECT articles.id, articles.libelle, articles.description, articles.image, articles.prix, articles.quantite, categorie.libelle 
    as 'categorie' FROM articles  INNER JOIN categorie  ON articles.idCategorie = categorie.id
    where articles.id = :id";
    $stmt = $pdo->prepare($req);
    $stmt->bindValue(":id",$id,PDO::PARAM_INT);
    $stmt->execute();
    $articles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    //print_r($articles);
    $stmt->closeCursor();
   sendJSON($articles);
   
}
//Affichage JSON
function sendJSON($infos){
    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json");
    echo json_encode($infos,JSON_UNESCAPED_UNICODE);
     /*var_dump(json_encode($infos,JSON_UNESCAPED_UNICODE));
    die();*/
}



?>